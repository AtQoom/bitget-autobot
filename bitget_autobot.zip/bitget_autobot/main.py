# Main bot logic
print('Bitget Auto Bot Running')