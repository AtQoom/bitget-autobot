# Bitget Auto Trading Bot

Webhook-driven auto trader for Bitget.